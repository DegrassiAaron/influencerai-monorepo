# MCP Kit (wrappers STDIO per Codex)

1. Copia `.env.example` → `.env.local` e inserisci i token (non committare).
2. Esegui i wrapper in `wrappers/*.ps1` per avviare i server MCP via `docker run -i` (STDIO).
3. Il repo principale punta a questi wrapper tramite `.codex/mcp.toml`.
